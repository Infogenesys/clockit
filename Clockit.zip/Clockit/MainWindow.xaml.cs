using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Forms;
using System.IO;

namespace Clockit
{
    public partial class MainWindow : Window
    {
        private readonly DispatcherTimer _timer;
        private bool _isDarkTheme = true;
        private bool _showColon = true;

        private NotifyIcon? _trayIcon;

        public MainWindow()
        {
            InitializeComponent();

            ApplyTheme();
            InitializeTrayIcon();
            StartFadeIn();

            _timer = new DispatcherTimer(DispatcherPriority.Normal);
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += UpdateClock;
            _timer.Start();

            UpdateClock();
        }

        // ================= CLOCK =================
        private void UpdateClock(object? sender = null, EventArgs? e = null)
        {
            DateTime now = DateTime.Now;

            _showColon = !_showColon;
            string sep = _showColon ? ":" : " ";

            DigitalClock.Text = $"{now:HH}{sep}{now:mm}{sep}{now:ss}";
        }

        // ================= THEME =================
        private void ThemeToggleButton_Click(object sender, RoutedEventArgs e)
        {
            _isDarkTheme = !_isDarkTheme;
            ApplyTheme();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void ApplyTheme()
        {
            if (_isDarkTheme)
            {
                RootBorder.Background = System.Windows.Media.Brushes.Black;
                DigitalClock.Foreground = System.Windows.Media.Brushes.Lime;
                ThemeToggleButton.Content = "💡";
                ThemeToggleButton.Foreground = System.Windows.Media.Brushes.White;
                CloseButton.Foreground = System.Windows.Media.Brushes.Lime;
            }
            else
            {
                RootBorder.Background = System.Windows.Media.Brushes.White;
                DigitalClock.Foreground = System.Windows.Media.Brushes.Crimson;
                ThemeToggleButton.Content = "🌙";
                ThemeToggleButton.Foreground = System.Windows.Media.Brushes.Black;
                CloseButton.Foreground = System.Windows.Media.Brushes.Crimson;
            }
        }

        // ================= FADE =================
        private void StartFadeIn()
        {
            var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(700));
            BeginAnimation(Window.OpacityProperty, fadeIn);
        }

        private void StartFadeOutAndExit()
        {
            var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(200));
            fadeOut.Completed += (_, _) =>
            {
                if (_trayIcon != null)
                {
                    _trayIcon.Visible = false;
                    _trayIcon.Dispose();
                }

                System.Windows.Application.Current.Shutdown();
            };

            BeginAnimation(Window.OpacityProperty, fadeOut);
        }

        // ================= TRAY =================
        private void InitializeTrayIcon()
        {
            _trayIcon = new NotifyIcon
            {
                Text = "Clockit",
                Icon = new System.Drawing.Icon(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "clockit.ico")),
                Visible = true
            };

            var menu = new ContextMenuStrip();
            menu.Items.Add("Show", null, (_, _) =>
            {
                Show();
                Activate();
            });

            menu.Items.Add("Exit", null, (_, _) =>
            {
                StartFadeOutAndExit();
            });

            _trayIcon.ContextMenuStrip = menu;

            _trayIcon.DoubleClick += (_, _) =>
            {
                Show();
                Activate();
            };
        }

        // ================= DRAG =================
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }
    }
}
