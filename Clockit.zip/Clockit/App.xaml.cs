using System.Windows;

namespace Clockit
{
    public partial class App : System.Windows.Application
    {
    }
}
